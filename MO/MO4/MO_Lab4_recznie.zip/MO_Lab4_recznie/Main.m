% MO - Laboratorium 4
% Jeden przebieg algorytmu genetycznego. Parametry zmieniaj recznie.
clear;
clc;
close all;

%% Ustawienia jednej proby
nazwa_proby = 'pop20';  % zmieniaj nazwe przed kolejnym uruchomieniem
size_pop = 20;          % 20, 40, 80
Pc = 0.8;               % 0.6, 0.8, 0.95
Pm = 0.05;              % 0.01, 0.05, 0.1
max_gen = 50;           % 20, 50, 100
index = 1;              % 1 = Jc1 (kwadraty), 2 = Jc2 (moduly)

w1 = 1;
w2 = 0.1;
tstop = 15;
bits = [10 14 14];
vlb = [0 0 0];
vub = [10 10 10];

rng('shuffle');
load_system('ex_5');

% W pliku prowadzacej jest 0.4^2. Z instrukcji wynika T1*T2=0.4*0.5.
set_param('ex_5/OBIEKT/Transfer Fcn', 'Denominator', '[0.4*0.5 (0.4+0.5) 1]');
set_param('ex_5/To Workspace', 'SaveFormat', 'Array');

%% Algorytm genetyczny
pop = double(rand(size_pop, sum(bits)) < 0.5);
J_hist = zeros(max_gen, 1);
K_hist = zeros(max_gen, 3);
J_naj = inf;
K_naj = [0 0 0];

for g = 1:max_gen
    nastawy = decode(pop, vlb, vub, bits);  % kolumny: Kp, Kd, Ki
    J_pop = zeros(size_pop, 1);

    for i = 1:size_pop
        Kp = nastawy(i, 1);
        Kd = nastawy(i, 2);
        Ki = nastawy(i, 3);

        set_param('ex_5/PID', 'Kp', num2str(Kp), ...
            'Kd', num2str(Kd), 'Ki', num2str(Ki));
        wynik = sim('ex_5', 'StopTime', num2str(tstop));
        dane = wynik.get('simout');

        r = dane(:, 2);
        y = dane(:, 3);
        u = dane(:, 4);

        if index == 1
            J = w1*sum((r-y).^2) + w2*sum(u.^2);
        else
            J = w1*sum(abs(r-y)) + w2*sum(abs(u));
        end

        if ~isfinite(J)
            J = 1e100;
        end
        J_pop(i) = J;
    end

    [J_gen, nr] = min(J_pop);
    if J_gen < J_naj
        J_naj = J_gen;
        K_naj = nastawy(nr, :);
    end

    J_hist(g) = J_naj;
    K_hist(g, :) = K_naj;
    fprintf('Generacja %3d / %3d     J = %.6f\n', g, max_gen, J_naj);

    if g < max_gen
        nowa = selection(pop, J_pop);
        nowa = mate(nowa);
        nowa = xover(nowa, Pc);
        nowa = mutate(nowa, Pm);
        nowa(1, :) = pop(nr, :);  % najlepszy osobnik przechodzi dalej
        pop = nowa;
    end
end

%% Najlepsza odpowiedz skokowa
set_param('ex_5/PID', 'Kp', num2str(K_naj(1)), ...
    'Kd', num2str(K_naj(2)), 'Ki', num2str(K_naj(3)));
wynik = sim('ex_5', 'StopTime', num2str(tstop));
dane = wynik.get('simout');
t = dane(:, 1);
r = dane(:, 2);
y = dane(:, 3);
u = dane(:, 4);

fprintf('\nProba: %s\n', nazwa_proby);
fprintf('size_pop=%d, Pc=%.2f, Pm=%.2f, max_gen=%d\n', size_pop, Pc, Pm, max_gen);
fprintf('Kp=%.5f, Kd=%.5f, Ki=%.5f, J=%.6f\n', K_naj(1), K_naj(2), K_naj(3), J_naj);

figure(1);
plot(1:max_gen, J_hist, 'k-', 'LineWidth', 1.2);
grid on;
xlabel('Generacja');
ylabel('J');
title('Najlepsza wartosc funkcji celu');

figure(2);
plot(1:max_gen, K_hist(:, 1), 'b-', ...
     1:max_gen, K_hist(:, 2), 'r-', ...
     1:max_gen, K_hist(:, 3), 'g-');
grid on;
xlabel('Generacja');
ylabel('Nastawy regulatora');
legend('Kp', 'Kd', 'Ki', 'Location', 'best');
title('Nastawy najlepszego regulatora');

figure(3);
plot(t, r, 'k--', t, y, 'b-');
grid on;
xlabel('Czas [s]');
ylabel('Odpowiedz ukladu');
legend('Wartosc zadana', 'Wyjscie', 'Location', 'best');
title('Odpowiedz skokowa dla najlepszego PID');

%% Zapis jednej proby (bez uruchamiania kolejnych testow)
if ~exist('wyniki', 'dir')
    mkdir('wyniki');
end
save(fullfile('wyniki', ['wynik_' nazwa_proby '.mat']), ...
    'size_pop', 'Pc', 'Pm', 'max_gen', 'index', 'K_naj', 'J_naj', ...
    'J_hist', 'K_hist', 't', 'r', 'y', 'u');
saveas(figure(1), fullfile('wyniki', ['J_' nazwa_proby '.png']));
saveas(figure(2), fullfile('wyniki', ['PID_' nazwa_proby '.png']));
saveas(figure(3), fullfile('wyniki', ['skok_' nazwa_proby '.png']));
