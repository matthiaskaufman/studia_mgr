function [new_gen, selected] = selection(old_gen, fitness)
% Ruletka: mniejsza wartosc J oznacza wieksza szanse wyboru.
fit = 1 ./ max(fitness(:), 1e-10);
p = fit / sum(fit);
p = cumsum(p);
n = size(old_gen, 1);
selected = zeros(n, 1);
for i = 1:n
    selected(i) = find(rand <= p, 1, 'first');
end
new_gen = old_gen(selected, :);
end
