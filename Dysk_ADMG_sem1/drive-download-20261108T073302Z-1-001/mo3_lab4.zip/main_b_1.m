clc; clear; close all;

%% === PARAMETRY I FUNKCJE ===
x0 = [-1, 2]; % Punkt startowy

% funkcje celu i ograniczeń
f = @(x) 100*(x(2) - x(1)^2)^2 + (1 - x(1))^2;
g = @(x) x(1) + x(2) - 2;
h = @(x) x(1) + x(2) - 3;

%% === AD 1. WYKRESY WARSTWICOWE W OTOCZENIU EKSTREMUM ===
[X, Y] = meshgrid(-10:0.05:10, -10:0.05:10);
Z_f = 100.*(Y - X.^2).^2 + (1 - X).^2;

figure(1);
[c, h_c] = contour(X, Y, Z_f, 50);
hold on;
% Ograniczenie g(x) = 0 -> x2 = 2 - x1
plot(X(1,:), 2 - X(1,:), 'k-', 'LineWidth', 2);
% Ograniczenie h(x) <= 0 -> x2 <= 3 - x1
plot(X(1,:), 3 - X(1,:), 'k--', 'LineWidth', 2);

%% FMINCON
A = [1, 1]; B = 3;       % h(x) <= 0
Aeq = [1, 1]; Beq = 2;   % g(x) = 0
options_con = optimoptions('fmincon', 'Display', 'none');
[x_fmincon, fval_fmincon] = fmincon(f, x0, A, B, Aeq, Beq, [], [], [], options_con);

%% Ekstremum analityczne i fmincon
plot(1, 1, 'rp', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
axis([-10 10, -10 10]);
title('Wykresy warstwicowe f(x) i ograniczenia');
xlabel('x_1'); ylabel('x_2');
plot(x_fmincon(1),x_fmincon(2), 'rp', 'MarkerSize', 12, 'MarkerFaceColor', 'b')
legend('Warstwice f(x)', 'g(x)=0 (równość)', 'h(x)=0 (granica nierówności)', 'Optimum [1,1]', 'fmincon', 'Location', 'best');
grid on;
hold off;

%% METODA FUNKCJI KARY (fminunc)
% Testujemy dla różnych wartości parametru r
r_values = [1, 1, 1]; 
r_values1 = [1, 10, 1000]; 
options_unc = optimoptions(@fminunc, 'Display', 'none', 'Algorithm', 'quasi-newton');

fprintf('Wyniki optymalizacji\n');
fprintf('fmincon: x = [%.4f, %.4f], f(x) = %.4f\n\n', x_fmincon(1), x_fmincon(2), fval_fmincon);

for i = 1:length(r_values)
    r = r_values(i);
    r1 = r_values1(i);
    % Zewnętrzna funkcja kary: F(x) = f(x) + r*g(x)^2 + r*(max(0, h(x)))^2
    F_kara = @(x) f(x) + r1*(g(x))^2 + r*(max(0, h(x)))^2;
    
    % Szukanie minimum funkcją fminunc
    [x_unc, fval_unc] = fminunc(F_kara, x0, options_unc);
    
    fprintf('Metoda kary dla r = %-4d: x = [%.4f, %.4f], F(x,r) = %.4f\n', r, x_unc(1), x_unc(2), fval_unc);
    
    % Wykres przestrzenny dla danej funkcji kary
    Z_kara = Z_f + r1.*(X + Y - 2).^2 + r.*(max(0, X + Y - 3)).^2;
    
    figure(1 + i);
    surf(X, Y, Z_kara, 'EdgeColor', 'interp');
    hold on;
    plot(x_unc(1),x_unc(2), '.', 'MarkerSize', 30, 'Color', 'r');
    title(sprintf('Wykres przestrzenny funkcji z karą (r = %d)', r));
    legend('','fminunc', 'Location', 'best');
    xlabel('x_1'); ylabel('x_2'); zlabel('F(x, r)');
    colormap jet; colorbar;
end